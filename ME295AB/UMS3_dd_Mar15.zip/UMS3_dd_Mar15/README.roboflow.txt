
UMS3_dd_Mar15 - v3 2022-03-15 9:17am
==============================

This dataset was exported via roboflow.ai on March 15, 2022 at 4:17 PM GMT

It includes 6018 images.
Defects are annotated in clip format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise, upside-down
* Random brigthness adjustment of between 0 and +13 percent


